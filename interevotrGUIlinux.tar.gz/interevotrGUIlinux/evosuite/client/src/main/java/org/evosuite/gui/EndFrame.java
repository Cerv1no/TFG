package org.evosuite.gui;
import java.awt.Desktop;
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.evosuite.Properties;
import org.evosuite.statistics.OutputVariable;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import java.io.IOException;


import javax.swing.SwingConstants;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import net.miginfocom.swing.MigLayout;
import javax.swing.JTextField;

public class EndFrame extends JFrame {

	private JPanel contentPane;
	private JTextField textField;

	/**
	 * frame for the end of the process with preference and final test suite link.
	 */
	public EndFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		contentPane = new JPanel();
		setLocationRelativeTo(null);
		setTitle("INTEREVO-TR");
		setIconImage(new ImageIcon(ClassLoader.getSystemResource("gui/evosuiteLogo.png")).getImage());
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		//title label settings
		JLabel lblTitle = new JLabel("Execution finished");
		lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitle.setFont(new Font("Times New Roman", Font.PLAIN, 23));
		
		//open button settings
		JButton btnOpen = new JButton("Open test suite final");
		btnOpen.setHorizontalTextPosition(SwingConstants.CENTER);
		btnOpen.setFocusPainted(false);
		btnOpen.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		
		String line = "";
		//gets all general values of the execution to display
		if (!Properties.OUTPUT_VARIABLE_MAP.isEmpty()) {
			for (OutputVariable<?> var : Properties.OUTPUT_VARIABLE_MAP.values()) {
				line = line + var.getName() + ": " + var.getValue() + System.lineSeparator();
	        }
			line = "<html>" + line.replace(System.lineSeparator(), "<br>") + "</html>";
		}	
		
		//open the final test suite in the user default code editor
		btnOpen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource()==btnOpen) {
					Desktop desktop = Desktop.getDesktop();
					//check if this feature is supported
					if (desktop.isDesktopSupported()) {
						//get the path of the interactive directory
						File dir = new File(Properties.INTERACTIVE_DIR);
						File[] files = dir.listFiles();
						//try to find the test amongst the files
						for (File file : files) {
							if (file.isFile() && file.getName().endsWith("ES_Test.java")) {
								try {
									desktop.open(file);
								} catch (IOException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}
							}
						}
					}
					//popup display if it isnt supported
					else {
						JOptionPane.showMessageDialog(btnOpen.getParent(),"We are sorry but this action is not"
								+ "supported on your platform. You can find the file in " + Properties.INTERACTIVE_DIR
								, "External editor", JOptionPane.INFORMATION_MESSAGE);
					}
					
				}
			}
		});
		
		//exit button settings
		JButton btnExit = new JButton("Exit");
		btnExit.setHorizontalTextPosition(SwingConstants.CENTER);
		btnExit.setFocusPainted(false);
		btnExit.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		
		//preference button settings
		JButton btnPreference = new JButton("Open preference file");
		btnPreference.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		btnPreference.setFocusPainted(false);
		
		//open the preference file in the user default code editor
		btnPreference.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == btnPreference) {
					Desktop desktop = Desktop.getDesktop();
					//check if this feature is supported
					if (desktop.isDesktopSupported()) {
						//get the path of the interactive directory
						File dir = new File(Properties.INTERACTIVE_DIR);
						File[] files = dir.listFiles();
						//try to find the test amongst the files
						for (File file : files) {
							if (file.isFile() && file.getName().endsWith("preferences_Test.java")) {
								try {
									desktop.open(file);
								} catch (IOException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}
							}
						}
					}
					//popup display if it isnt supported
					else {
						JOptionPane.showMessageDialog(btnPreference.getParent(),"We are sorry but this action is not"
								+ "supported on your platform. You can find the files in " + Properties.OUTPUT_DIR
								, "External editor", JOptionPane.INFORMATION_MESSAGE);
					}
				}
			}
		});
		contentPane.setLayout(new MigLayout("", "[100px:140.00px,grow][100px:n,grow][100px:n,grow][][100px:n,grow]", "[100px:11.00,grow][100px:76.00px,grow][100px:n,grow][100px:72.00,grow][100px:310.00px,grow][559.00px,grow]"));
		contentPane.add(lblTitle, "cell 1 0 2 1,alignx center,growy");
		
		//output variables label settings
		JLabel lblVariables = new JLabel(line);
		lblVariables.setHorizontalAlignment(SwingConstants.CENTER);
		lblVariables.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		
		contentPane.add(lblVariables, "cell 1 1 2 3,growx");
		contentPane.add(btnExit, "cell 0 5 5 1,alignx center,aligny center");
		contentPane.add(btnOpen, "cell 0 2,alignx center,aligny center");
		contentPane.add(btnPreference, "cell 3 2 2 1,alignx center,aligny center");
		
		setSize(1200, 800);
		setMinimumSize(new Dimension(1200, 800));
		setLocationRelativeTo(null);
		this.setVisible(true);
		
		//close frame when clicked
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource()==btnExit) {
					setVisible(false);
				}
			}
		});
	}
}
